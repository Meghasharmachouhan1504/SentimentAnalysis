```python
import numpy as np
import pandas as pd
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import re
from textblob import TextBlob
from wordcloud import WordCloud
import seaborn as sns
import matplotlib.pyplot as plt
import cufflinks as cf 
%matplotlib inline
from plotly.offline import init_notebook_mode, iplot
init_notebook_mode (connected = True)
cf.go_offline();
import plotly.graph_objs as go
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings ("ignore")
warnings.warn("this will not show")
pd.set_option('display.max_columns', None)
```


<script type="text/javascript">
window.PlotlyConfig = {MathJaxConfig: 'local'};
if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}
if (typeof require !== 'undefined') {
require.undef("plotly");
requirejs.config({
    paths: {
        'plotly': ['https://cdn.plot.ly/plotly-2.26.0.min']
    }
});
require(['plotly'], function(Plotly) {
    window._Plotly = Plotly;
});
}
</script>




<script type="text/javascript">
window.PlotlyConfig = {MathJaxConfig: 'local'};
if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}
if (typeof require !== 'undefined') {
require.undef("plotly");
requirejs.config({
    paths: {
        'plotly': ['https://cdn.plot.ly/plotly-2.26.0.min']
    }
});
require(['plotly'], function(Plotly) {
    window._Plotly = Plotly;
});
}
</script>




```python
df = pd.read_csv("amazon.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>reviewerName</th>
      <th>overall</th>
      <th>reviewText</th>
      <th>reviewTime</th>
      <th>day_diff</th>
      <th>helpful_yes</th>
      <th>helpful_no</th>
      <th>total_vote</th>
      <th>score_pos_neg_diff</th>
      <th>score_average_rating</th>
      <th>wilson_lower_bound</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>NaN</td>
      <td>4</td>
      <td>No issues.</td>
      <td>23-07-2014</td>
      <td>138</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0mie</td>
      <td>5</td>
      <td>Purchased this for my device, it worked as adv...</td>
      <td>25-10-2013</td>
      <td>409</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1K3</td>
      <td>4</td>
      <td>it works as expected. I should have sprung for...</td>
      <td>23-12-2012</td>
      <td>715</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>1m2</td>
      <td>5</td>
      <td>This think has worked out great.Had a diff. br...</td>
      <td>21-11-2013</td>
      <td>382</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2&amp;amp;1/2Men</td>
      <td>5</td>
      <td>Bought it with Retail Packaging, arrived legit...</td>
      <td>13-07-2013</td>
      <td>513</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>reviewerName</th>
      <th>overall</th>
      <th>reviewText</th>
      <th>reviewTime</th>
      <th>day_diff</th>
      <th>helpful_yes</th>
      <th>helpful_no</th>
      <th>total_vote</th>
      <th>score_pos_neg_diff</th>
      <th>score_average_rating</th>
      <th>wilson_lower_bound</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>NaN</td>
      <td>4</td>
      <td>No issues.</td>
      <td>23-07-2014</td>
      <td>138</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0mie</td>
      <td>5</td>
      <td>Purchased this for my device, it worked as adv...</td>
      <td>25-10-2013</td>
      <td>409</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1K3</td>
      <td>4</td>
      <td>it works as expected. I should have sprung for...</td>
      <td>23-12-2012</td>
      <td>715</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>1m2</td>
      <td>5</td>
      <td>This think has worked out great.Had a diff. br...</td>
      <td>21-11-2013</td>
      <td>382</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2&amp;amp;1/2Men</td>
      <td>5</td>
      <td>Bought it with Retail Packaging, arrived legit...</td>
      <td>13-07-2013</td>
      <td>513</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4910</th>
      <td>4910</td>
      <td>ZM "J"</td>
      <td>1</td>
      <td>I bought this Sandisk 16GB Class 10 to use wit...</td>
      <td>23-07-2013</td>
      <td>503</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4911</th>
      <td>4911</td>
      <td>Zo</td>
      <td>5</td>
      <td>Used this for extending the capabilities of my...</td>
      <td>22-08-2013</td>
      <td>473</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4912</th>
      <td>4912</td>
      <td>Z S Liske</td>
      <td>5</td>
      <td>Great card that is very fast and reliable. It ...</td>
      <td>31-03-2014</td>
      <td>252</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4913</th>
      <td>4913</td>
      <td>Z Taylor</td>
      <td>5</td>
      <td>Good amount of space for the stuff I want to d...</td>
      <td>16-09-2013</td>
      <td>448</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4914</th>
      <td>4914</td>
      <td>Zza</td>
      <td>5</td>
      <td>I've heard bad things about this 64gb Micro SD...</td>
      <td>01-02-2014</td>
      <td>310</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>4915 rows × 12 columns</p>
</div>




```python
df = df.sort_values("wilson_lower_bound", ascending = False)
df.drop ('Unnamed: 0', inplace = True, axis=1)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>reviewerName</th>
      <th>overall</th>
      <th>reviewText</th>
      <th>reviewTime</th>
      <th>day_diff</th>
      <th>helpful_yes</th>
      <th>helpful_no</th>
      <th>total_vote</th>
      <th>score_pos_neg_diff</th>
      <th>score_average_rating</th>
      <th>wilson_lower_bound</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2031</th>
      <td>Hyoun Kim "Faluzure"</td>
      <td>5</td>
      <td>[[ UPDATE - 6/19/2014 ]]So my lovely wife boug...</td>
      <td>05-01-2013</td>
      <td>702</td>
      <td>1952</td>
      <td>68</td>
      <td>2020</td>
      <td>1884</td>
      <td>0.966337</td>
      <td>0.957544</td>
    </tr>
    <tr>
      <th>3449</th>
      <td>NLee the Engineer</td>
      <td>5</td>
      <td>I have tested dozens of SDHC and micro-SDHC ca...</td>
      <td>26-09-2012</td>
      <td>803</td>
      <td>1428</td>
      <td>77</td>
      <td>1505</td>
      <td>1351</td>
      <td>0.948837</td>
      <td>0.936519</td>
    </tr>
    <tr>
      <th>4212</th>
      <td>SkincareCEO</td>
      <td>1</td>
      <td>NOTE:  please read the last update (scroll to ...</td>
      <td>08-05-2013</td>
      <td>579</td>
      <td>1568</td>
      <td>126</td>
      <td>1694</td>
      <td>1442</td>
      <td>0.925620</td>
      <td>0.912139</td>
    </tr>
    <tr>
      <th>317</th>
      <td>Amazon Customer "Kelly"</td>
      <td>1</td>
      <td>If your card gets hot enough to be painful, it...</td>
      <td>09-02-2012</td>
      <td>1033</td>
      <td>422</td>
      <td>73</td>
      <td>495</td>
      <td>349</td>
      <td>0.852525</td>
      <td>0.818577</td>
    </tr>
    <tr>
      <th>4672</th>
      <td>Twister</td>
      <td>5</td>
      <td>Sandisk announcement of the first 128GB micro ...</td>
      <td>03-07-2014</td>
      <td>158</td>
      <td>45</td>
      <td>4</td>
      <td>49</td>
      <td>41</td>
      <td>0.918367</td>
      <td>0.808109</td>
    </tr>
  </tbody>
</table>
</div>




```python
def missing_values_analysis(df):
    na_columns = [col for col in df.columns if df[col].isnull().sum() > 0]
    n_miss = df[na_columns].isnull().sum().sort_values(ascending=True)
    ratio = (df[na_columns].isnull().sum() / df.shape[0] * 100).sort_values(ascending=True)
    missing_df = pd.concat([n_miss, np.round(ratio, 2)], axis=1, keys=['Missing Values', 'Ratio'])
    return missing_df

def check_dataframe(df, head=5, tail=5):
    print("SHAPE".center(82, '~'))
    print('Rows: {}'.format(df.shape[0]))
    print('Columns: {}'.format(df.shape[1]))
    print("TYPES".center(82, '~'))
    print(df.dtypes)
    print("".center(82, '~'))
    print(missing_values_analysis(df))
    print('DUPLICATED VALUES'.center(83, '~'))
    print(df.duplicated().sum())
    print("QUANTILES".center(82, '~'))
    
    # Filter numeric columns before calculating quantiles
    numeric_columns = df.select_dtypes(include=[np.number]).columns
    print(df[numeric_columns].quantile([0, 0.05, 0.50, 0.95, 0.99, 1]).T)

check_dataframe(df)


```

    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SHAPE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Rows: 4915
    Columns: 11
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~TYPES~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    reviewerName             object
    overall                   int64
    reviewText               object
    reviewTime               object
    day_diff                  int64
    helpful_yes               int64
    helpful_no                int64
    total_vote                int64
    score_pos_neg_diff        int64
    score_average_rating    float64
    wilson_lower_bound      float64
    dtype: object
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                  Missing Values  Ratio
    reviewerName               1   0.02
    reviewText                 1   0.02
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~DUPLICATED VALUES~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    0
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~QUANTILES~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                           0.00  0.05   0.50        0.95       0.99         1.00
    overall                 1.0   2.0    5.0    5.000000    5.00000     5.000000
    day_diff                1.0  98.0  431.0  748.000000  943.00000  1064.000000
    helpful_yes             0.0   0.0    0.0    1.000000    3.00000  1952.000000
    helpful_no              0.0   0.0    0.0    0.000000    2.00000   183.000000
    total_vote              0.0   0.0    0.0    1.000000    4.00000  2020.000000
    score_pos_neg_diff   -130.0   0.0    0.0    1.000000    2.00000  1884.000000
    score_average_rating    0.0   0.0    0.0    1.000000    1.00000     1.000000
    wilson_lower_bound      0.0   0.0    0.0    0.206549    0.34238     0.957544



```python
def check_class (dataframe):
    nunique_df = pd. DataFrame({ 'Variable': dataframe.columns,
                                'Classes': [dataframe[i].nunique() \
                                        for i in dataframe.columns]})
    nunique_df = nunique_df.sort_values ('Classes', ascending = False)
    nunique_df = nunique_df.reset_index (drop = True)
    return nunique_df
check_class (df)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Variable</th>
      <th>Classes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>reviewText</td>
      <td>4912</td>
    </tr>
    <tr>
      <th>1</th>
      <td>reviewerName</td>
      <td>4594</td>
    </tr>
    <tr>
      <th>2</th>
      <td>reviewTime</td>
      <td>690</td>
    </tr>
    <tr>
      <th>3</th>
      <td>day_diff</td>
      <td>690</td>
    </tr>
    <tr>
      <th>4</th>
      <td>wilson_lower_bound</td>
      <td>40</td>
    </tr>
    <tr>
      <th>5</th>
      <td>score_average_rating</td>
      <td>28</td>
    </tr>
    <tr>
      <th>6</th>
      <td>score_pos_neg_diff</td>
      <td>27</td>
    </tr>
    <tr>
      <th>7</th>
      <td>total_vote</td>
      <td>26</td>
    </tr>
    <tr>
      <th>8</th>
      <td>helpful_yes</td>
      <td>23</td>
    </tr>
    <tr>
      <th>9</th>
      <td>helpful_no</td>
      <td>17</td>
    </tr>
    <tr>
      <th>10</th>
      <td>overall</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt

def categorical_variable_summary(df, column_name):
    # Create a bar chart
    plt.figure(figsize=(10, 5))
    df[column_name].value_counts().plot(kind='bar', color=constraints)
    plt.title(f'{column_name} Countplot')
    plt.xlabel(column_name)
    plt.ylabel('Count')
    plt.show()

    # Create a pie chart
    plt.figure(figsize=(8, 8))
    df[column_name].value_counts().plot(kind='pie', autopct='%1.1f%%', colors=constraints)
    plt.title(f'{column_name} Percentage')
    plt.ylabel('')
    plt.show()





```


```python
categorical_variable_summary(df, 'overall')
```


    
![png](output_8_0.png)
    



    
![png](output_8_1.png)
    



```python
df.reviewText.head()
```




    2031    [[ UPDATE - 6/19/2014 ]]So my lovely wife boug...
    3449    I have tested dozens of SDHC and micro-SDHC ca...
    4212    NOTE:  please read the last update (scroll to ...
    317     If your card gets hot enough to be painful, it...
    4672    Sandisk announcement of the first 128GB micro ...
    Name: reviewText, dtype: object




```python
review_example = df.reviewText [2031]
review_example
```




    '[[ UPDATE - 6/19/2014 ]]So my lovely wife bought me a Samsung Galaxy Tab 4 for Father\'s Day and I\'ve been loving it ever since.  Just as other with Samsung products, the Galaxy Tab 4 has the ability to add a microSD card to expand the memory on the device.  Since it\'s been over a year, I decided to do some more research to see if SanDisk offered anything new.  As of 6/19/2014, their product lineup for microSD cards from worst to best (performance-wise) are the as follows:SanDiskSanDisk UltraSanDisk Ultra PLUSSanDisk ExtremeSanDisk Extreme PLUSSanDisk Extreme PRONow, the difference between all of these cards are simply the speed in which you can read/write data to the card.  Yes, the published rating of most all these cards (except the SanDisk regular) are Class 10/UHS-I but that\'s just a rating... Actual real world performance does get better with each model, but with faster cards come more expensive prices.  Since Amazon doesn\'t carry the Ultra PLUS model of microSD card, I had to do direct comparisons between the SanDisk Ultra ($34.27), Extreme ($57.95), and Extreme PLUS ($67.95).As mentioned in my earlier review, I purchased the SanDisk Ultra for my Galaxy S4.  My question was, did I want to pay over $20 more for a card that is faster than the one I already owned?  Or I could pay almost double to get SanDisk\'s 2nd-most fastest microSD card.The Ultra works perfectly fine for my style of usage (storing/capturing pictures & HD video and movie playback) on my phone.  So in the end, I ended up just buying another SanDisk Ultra 64GB card.  I use my cell phone *more* than I do my tablet and if the card is good enough for my phone, it\'s good enough for my tablet.  I don\'t own a 4K HD camera or anything like that, so I honestly didn\'t see a need to get one of the faster cards at this time.I am now a proud owner of 2 SanDisk Ultra cards and have absolutely 0 issues with it in my Samsung devices.[[ ORIGINAL REVIEW - 5/1/2013 ]]I haven\'t had to buy a microSD card in a long time. The last time I bought one was for my cell phone over 2 years ago. But since my cellular contract was up, I knew I would have to get a newer card in addition to my new phone, the Samsung Galaxy S4. Reason for this is because I knew my small 16GB microSD card wasn\'t going to cut it.Doing research on the Galaxy S4, I wanted to get the best card possible that had decent capacity (32 GB or greater). This led me to find that the Galaxy S4 supports the microSDXC Class 10 UHS-I card, which is the fastest possible given that class. Searching for that specifically on Amazon gave me results of only 3 vendors (as of April) that makes these microSDXC Class 10 UHS-1 cards. They are Sandisk (the majority), Samsung and Lexar. Nobody else makes these that are sold on Amazon.Seeing how SanDisk is a pretty good name out of the 3 (I\'ve used them the most), I decided upon the SanDisk because Lexar was overpriced and the Samsung one was overpriced (as well as not eligible for Amazon Prime).But the scary thing is that when you filter by the SanDisk, you literally get DOZENS of options. All of them have different model numbers, different sizes, etc. Then there\'s that confusion of what\'s the difference between SDHC & SDXC?SDHC vs SDXC:SDHC stand for "Secure Digital High Capacity" and SDXC stands for "Secure Digital eXtended Capacity". Essentially these two cards are the same with the exception that SDHC only supports capcities up to 32GB and is formated with the FAT32 file system. The SDXC cards are formatted with the exFAT file system. If you use an SDXC card in a device, it must support that file system, otherwise it may not be recognizable and/or you have to reformat the card to FAT32.FAT32 vs exFAT:The differences between the two file systems means that FAT32 has a maximum file size of 4GB, limited by that file system. exFAT on the otherhand, supports file sizes up to 2TB (terabytes). The only thing you need to know here really is that it\'s possible your device doesn\'t support exFAT. If that\'s the case, just reformat it to FAT32. REMEMBER FORMATTING ERASES ALL DATA!To clarify the model numbers, I I hopped over to the SanDisk official webpage. What I found there is that they offer two "highspeed" options for SanDisk cards. These are SanDisk Extreme Pro and SanDisk Ultra. SanDisk Extreme Pro is a line that supports read speeds up to 95MB/sec, however they are SDHC only. To make things worse, they are currently only available in 16GB & 8GB capacities. Since one of my requirements was to have a lot of storage, I ruled these out.The remaining devices listed on Amazon\'s search were the SanDisk Ultra line. But here, confusion sets in because SanDisk separates these cards to two different devices. Cameras & mobile devices. Is there a real difference between the two or is this just a marketing stunt? Unfortunately I\'m not sure but I do know the price difference between the two range from a couple cents to a few dollars. Since I wasn\'t sure, I opted for the one specifically targeted for mobile devices (just in case there is some kind of compatibility issue). To find the exact model number, I would go to Sandisk\'s webpage (sandisk.com) and compare their existing product lineup. From there, you get exact model numbers and you can then search Amazon for these model numbers. That is how I got mine (SDSDQUA-064G).As for speed tests, I haven\'t run any specific testing, but copying 8 GB worth of data from my PC to the card literally took just a few minutes.One last note is that Amazon attaches additional characters to the end (for example SDSDQUA-064G-AFFP-A vs SDSDQUA-064G-U46A). The difference between the two is that the "AFFP-A" means "Amazon Frustration Free Packaging". Other than that, these are exactly the same.  If you\'re wondering what I got (and want to use it in your Galaxy S4), I got the SDSDQUA-064G-u46A and it works like charm.'




```python
review_example = df.reviewText[2031]

# Apply the substitution to remove non-alphabetic characters
review_example = re.sub("[^a-zA-Z ]", '', review_example)





```


```python
# Split the string into individual words
review_example = review_example.lower().split()

```


```python
review_example
```




    ['update',
     'so',
     'my',
     'lovely',
     'wife',
     'bought',
     'me',
     'a',
     'samsung',
     'galaxy',
     'tab',
     'for',
     'fathers',
     'day',
     'and',
     'ive',
     'been',
     'loving',
     'it',
     'ever',
     'since',
     'just',
     'as',
     'other',
     'with',
     'samsung',
     'products',
     'the',
     'galaxy',
     'tab',
     'has',
     'the',
     'ability',
     'to',
     'add',
     'a',
     'microsd',
     'card',
     'to',
     'expand',
     'the',
     'memory',
     'on',
     'the',
     'device',
     'since',
     'its',
     'been',
     'over',
     'a',
     'year',
     'i',
     'decided',
     'to',
     'do',
     'some',
     'more',
     'research',
     'to',
     'see',
     'if',
     'sandisk',
     'offered',
     'anything',
     'new',
     'as',
     'of',
     'their',
     'product',
     'lineup',
     'for',
     'microsd',
     'cards',
     'from',
     'worst',
     'to',
     'best',
     'performancewise',
     'are',
     'the',
     'as',
     'followssandisksandisk',
     'ultrasandisk',
     'ultra',
     'plussandisk',
     'extremesandisk',
     'extreme',
     'plussandisk',
     'extreme',
     'pronow',
     'the',
     'difference',
     'between',
     'all',
     'of',
     'these',
     'cards',
     'are',
     'simply',
     'the',
     'speed',
     'in',
     'which',
     'you',
     'can',
     'readwrite',
     'data',
     'to',
     'the',
     'card',
     'yes',
     'the',
     'published',
     'rating',
     'of',
     'most',
     'all',
     'these',
     'cards',
     'except',
     'the',
     'sandisk',
     'regular',
     'are',
     'class',
     'uhsi',
     'but',
     'thats',
     'just',
     'a',
     'rating',
     'actual',
     'real',
     'world',
     'performance',
     'does',
     'get',
     'better',
     'with',
     'each',
     'model',
     'but',
     'with',
     'faster',
     'cards',
     'come',
     'more',
     'expensive',
     'prices',
     'since',
     'amazon',
     'doesnt',
     'carry',
     'the',
     'ultra',
     'plus',
     'model',
     'of',
     'microsd',
     'card',
     'i',
     'had',
     'to',
     'do',
     'direct',
     'comparisons',
     'between',
     'the',
     'sandisk',
     'ultra',
     'extreme',
     'and',
     'extreme',
     'plus',
     'as',
     'mentioned',
     'in',
     'my',
     'earlier',
     'review',
     'i',
     'purchased',
     'the',
     'sandisk',
     'ultra',
     'for',
     'my',
     'galaxy',
     's',
     'my',
     'question',
     'was',
     'did',
     'i',
     'want',
     'to',
     'pay',
     'over',
     'more',
     'for',
     'a',
     'card',
     'that',
     'is',
     'faster',
     'than',
     'the',
     'one',
     'i',
     'already',
     'owned',
     'or',
     'i',
     'could',
     'pay',
     'almost',
     'double',
     'to',
     'get',
     'sandisks',
     'ndmost',
     'fastest',
     'microsd',
     'cardthe',
     'ultra',
     'works',
     'perfectly',
     'fine',
     'for',
     'my',
     'style',
     'of',
     'usage',
     'storingcapturing',
     'pictures',
     'hd',
     'video',
     'and',
     'movie',
     'playback',
     'on',
     'my',
     'phone',
     'so',
     'in',
     'the',
     'end',
     'i',
     'ended',
     'up',
     'just',
     'buying',
     'another',
     'sandisk',
     'ultra',
     'gb',
     'card',
     'i',
     'use',
     'my',
     'cell',
     'phone',
     'more',
     'than',
     'i',
     'do',
     'my',
     'tablet',
     'and',
     'if',
     'the',
     'card',
     'is',
     'good',
     'enough',
     'for',
     'my',
     'phone',
     'its',
     'good',
     'enough',
     'for',
     'my',
     'tablet',
     'i',
     'dont',
     'own',
     'a',
     'k',
     'hd',
     'camera',
     'or',
     'anything',
     'like',
     'that',
     'so',
     'i',
     'honestly',
     'didnt',
     'see',
     'a',
     'need',
     'to',
     'get',
     'one',
     'of',
     'the',
     'faster',
     'cards',
     'at',
     'this',
     'timei',
     'am',
     'now',
     'a',
     'proud',
     'owner',
     'of',
     'sandisk',
     'ultra',
     'cards',
     'and',
     'have',
     'absolutely',
     'issues',
     'with',
     'it',
     'in',
     'my',
     'samsung',
     'devices',
     'original',
     'review',
     'i',
     'havent',
     'had',
     'to',
     'buy',
     'a',
     'microsd',
     'card',
     'in',
     'a',
     'long',
     'time',
     'the',
     'last',
     'time',
     'i',
     'bought',
     'one',
     'was',
     'for',
     'my',
     'cell',
     'phone',
     'over',
     'years',
     'ago',
     'but',
     'since',
     'my',
     'cellular',
     'contract',
     'was',
     'up',
     'i',
     'knew',
     'i',
     'would',
     'have',
     'to',
     'get',
     'a',
     'newer',
     'card',
     'in',
     'addition',
     'to',
     'my',
     'new',
     'phone',
     'the',
     'samsung',
     'galaxy',
     's',
     'reason',
     'for',
     'this',
     'is',
     'because',
     'i',
     'knew',
     'my',
     'small',
     'gb',
     'microsd',
     'card',
     'wasnt',
     'going',
     'to',
     'cut',
     'itdoing',
     'research',
     'on',
     'the',
     'galaxy',
     's',
     'i',
     'wanted',
     'to',
     'get',
     'the',
     'best',
     'card',
     'possible',
     'that',
     'had',
     'decent',
     'capacity',
     'gb',
     'or',
     'greater',
     'this',
     'led',
     'me',
     'to',
     'find',
     'that',
     'the',
     'galaxy',
     's',
     'supports',
     'the',
     'microsdxc',
     'class',
     'uhsi',
     'card',
     'which',
     'is',
     'the',
     'fastest',
     'possible',
     'given',
     'that',
     'class',
     'searching',
     'for',
     'that',
     'specifically',
     'on',
     'amazon',
     'gave',
     'me',
     'results',
     'of',
     'only',
     'vendors',
     'as',
     'of',
     'april',
     'that',
     'makes',
     'these',
     'microsdxc',
     'class',
     'uhs',
     'cards',
     'they',
     'are',
     'sandisk',
     'the',
     'majority',
     'samsung',
     'and',
     'lexar',
     'nobody',
     'else',
     'makes',
     'these',
     'that',
     'are',
     'sold',
     'on',
     'amazonseeing',
     'how',
     'sandisk',
     'is',
     'a',
     'pretty',
     'good',
     'name',
     'out',
     'of',
     'the',
     'ive',
     'used',
     'them',
     'the',
     'most',
     'i',
     'decided',
     'upon',
     'the',
     'sandisk',
     'because',
     'lexar',
     'was',
     'overpriced',
     'and',
     'the',
     'samsung',
     'one',
     'was',
     'overpriced',
     'as',
     'well',
     'as',
     'not',
     'eligible',
     'for',
     'amazon',
     'primebut',
     'the',
     'scary',
     'thing',
     'is',
     'that',
     'when',
     'you',
     'filter',
     'by',
     'the',
     'sandisk',
     'you',
     'literally',
     'get',
     'dozens',
     'of',
     'options',
     'all',
     'of',
     'them',
     'have',
     'different',
     'model',
     'numbers',
     'different',
     'sizes',
     'etc',
     'then',
     'theres',
     'that',
     'confusion',
     'of',
     'whats',
     'the',
     'difference',
     'between',
     'sdhc',
     'sdxcsdhc',
     'vs',
     'sdxcsdhc',
     'stand',
     'for',
     'secure',
     'digital',
     'high',
     'capacity',
     'and',
     'sdxc',
     'stands',
     'for',
     'secure',
     'digital',
     'extended',
     'capacity',
     'essentially',
     'these',
     'two',
     'cards',
     'are',
     'the',
     'same',
     'with',
     'the',
     'exception',
     'that',
     'sdhc',
     'only',
     'supports',
     'capcities',
     'up',
     'to',
     'gb',
     'and',
     'is',
     'formated',
     'with',
     'the',
     'fat',
     'file',
     'system',
     'the',
     'sdxc',
     'cards',
     'are',
     'formatted',
     'with',
     'the',
     'exfat',
     'file',
     'system',
     'if',
     'you',
     'use',
     'an',
     'sdxc',
     'card',
     'in',
     'a',
     'device',
     'it',
     'must',
     'support',
     'that',
     'file',
     'system',
     'otherwise',
     'it',
     'may',
     'not',
     'be',
     'recognizable',
     'andor',
     'you',
     'have',
     'to',
     'reformat',
     'the',
     'card',
     'to',
     'fatfat',
     'vs',
     'exfatthe',
     'differences',
     'between',
     'the',
     'two',
     'file',
     'systems',
     'means',
     'that',
     'fat',
     'has',
     'a',
     'maximum',
     'file',
     'size',
     'of',
     'gb',
     'limited',
     'by',
     'that',
     'file',
     'system',
     'exfat',
     'on',
     'the',
     'otherhand',
     'supports',
     'file',
     'sizes',
     'up',
     'to',
     'tb',
     'terabytes',
     'the',
     'only',
     'thing',
     'you',
     'need',
     'to',
     'know',
     'here',
     'really',
     'is',
     'that',
     'its',
     'possible',
     'your',
     'device',
     'doesnt',
     'support',
     'exfat',
     'if',
     'thats',
     'the',
     'case',
     'just',
     'reformat',
     'it',
     'to',
     'fat',
     'remember',
     'formatting',
     'erases',
     'all',
     'datato',
     'clarify',
     'the',
     'model',
     'numbers',
     'i',
     'i',
     'hopped',
     'over',
     'to',
     'the',
     'sandisk',
     'official',
     'webpage',
     'what',
     'i',
     'found',
     'there',
     'is',
     'that',
     'they',
     'offer',
     'two',
     'highspeed',
     'options',
     'for',
     'sandisk',
     'cards',
     'these',
     'are',
     'sandisk',
     'extreme',
     'pro',
     'and',
     'sandisk',
     'ultra',
     'sandisk',
     'extreme',
     'pro',
     'is',
     'a',
     'line',
     'that',
     'supports',
     'read',
     'speeds',
     'up',
     'to',
     'mbsec',
     'however',
     'they',
     'are',
     'sdhc',
     'only',
     'to',
     'make',
     'things',
     'worse',
     'they',
     'are',
     'currently',
     'only',
     'available',
     'in',
     'gb',
     'gb',
     'capacities',
     'since',
     'one',
     'of',
     'my',
     'requirements',
     'was',
     'to',
     'have',
     'a',
     'lot',
     'of',
     'storage',
     'i',
     'ruled',
     'these',
     'outthe',
     'remaining',
     'devices',
     'listed',
     'on',
     'amazons',
     'search',
     'were',
     'the',
     'sandisk',
     'ultra',
     'line',
     'but',
     'here',
     'confusion',
     'sets',
     'in',
     'because',
     'sandisk',
     'separates',
     'these',
     'cards',
     'to',
     'two',
     'different',
     'devices',
     'cameras',
     'mobile',
     'devices',
     'is',
     'there',
     'a',
     'real',
     'difference',
     'between',
     'the',
     'two',
     'or',
     'is',
     'this',
     'just',
     'a',
     'marketing',
     'stunt',
     'unfortunately',
     'im',
     'not',
     'sure',
     'but',
     'i',
     'do',
     'know',
     'the',
     'price',
     'difference',
     'between',
     'the',
     'two',
     'range',
     'from',
     'a',
     'couple',
     'cents',
     'to',
     'a',
     'few',
     'dollars',
     'since',
     'i',
     'wasnt',
     'sure',
     'i',
     'opted',
     'for',
     'the',
     'one',
     'specifically',
     'targeted',
     'for',
     'mobile',
     'devices',
     'just',
     'in',
     'case',
     'there',
     'is',
     'some',
     'kind',
     'of',
     'compatibility',
     'issue',
     'to',
     'find',
     'the',
     'exact',
     'model',
     'number',
     'i',
     'would',
     'go',
     'to',
     'sandisks',
     'webpage',
     'sandiskcom',
     'and',
     'compare',
     'their',
     'existing',
     'product',
     'lineup',
     'from',
     'there',
     'you',
     'get',
     'exact',
     'model',
     'numbers',
     'and',
     'you',
     'can',
     'then',
     'search',
     'amazon',
     'for',
     'these',
     'model',
     'numbers',
     'that',
     'is',
     'how',
     'i',
     'got',
     'mine',
     'sdsdquagas',
     'for',
     'speed',
     'tests',
     'i',
     'havent',
     'run',
     'any',
     'specific',
     'testing',
     'but',
     'copying',
     'gb',
     'worth',
     'of',
     'data',
     'from',
     'my',
     'pc',
     'to',
     'the',
     'card',
     'literally',
     'took',
     'just',
     'a',
     'few',
     'minutesone',
     'last',
     'note',
     'is',
     'that',
     'amazon',
     'attaches',
     'additional',
     'characters',
     'to',
     'the',
     'end',
     'for',
     'example',
     'sdsdquagaffpa',
     'vs',
     'sdsdquagua',
     'the',
     'difference',
     'between',
     'the',
     'two',
     'is',
     'that',
     'the',
     'affpa',
     'means',
     'amazon',
     'frustration',
     'free',
     'packaging',
     'other',
     'than',
     'that',
     'these',
     'are',
     'exactly',
     'the',
     'same',
     'if',
     'youre',
     'wondering',
     'what',
     'i',
     'got',
     'and',
     'want',
     'to',
     'use',
     'it',
     ...]




```python
rt = lambda x: re.sub("[^a-zA-Z]",' ' ,str(x))
df["reviewText"] = df["reviewText"].map(rt)
df ["reviewText"]= df["reviewText"].str.lower()
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>reviewerName</th>
      <th>overall</th>
      <th>reviewText</th>
      <th>reviewTime</th>
      <th>day_diff</th>
      <th>helpful_yes</th>
      <th>helpful_no</th>
      <th>total_vote</th>
      <th>score_pos_neg_diff</th>
      <th>score_average_rating</th>
      <th>wilson_lower_bound</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2031</th>
      <td>Hyoun Kim "Faluzure"</td>
      <td>5</td>
      <td>update               so my lovely wife boug...</td>
      <td>05-01-2013</td>
      <td>702</td>
      <td>1952</td>
      <td>68</td>
      <td>2020</td>
      <td>1884</td>
      <td>0.966337</td>
      <td>0.957544</td>
    </tr>
    <tr>
      <th>3449</th>
      <td>NLee the Engineer</td>
      <td>5</td>
      <td>i have tested dozens of sdhc and micro sdhc ca...</td>
      <td>26-09-2012</td>
      <td>803</td>
      <td>1428</td>
      <td>77</td>
      <td>1505</td>
      <td>1351</td>
      <td>0.948837</td>
      <td>0.936519</td>
    </tr>
    <tr>
      <th>4212</th>
      <td>SkincareCEO</td>
      <td>1</td>
      <td>note   please read the last update  scroll to ...</td>
      <td>08-05-2013</td>
      <td>579</td>
      <td>1568</td>
      <td>126</td>
      <td>1694</td>
      <td>1442</td>
      <td>0.925620</td>
      <td>0.912139</td>
    </tr>
    <tr>
      <th>317</th>
      <td>Amazon Customer "Kelly"</td>
      <td>1</td>
      <td>if your card gets hot enough to be painful  it...</td>
      <td>09-02-2012</td>
      <td>1033</td>
      <td>422</td>
      <td>73</td>
      <td>495</td>
      <td>349</td>
      <td>0.852525</td>
      <td>0.818577</td>
    </tr>
    <tr>
      <th>4672</th>
      <td>Twister</td>
      <td>5</td>
      <td>sandisk announcement of the first    gb micro ...</td>
      <td>03-07-2014</td>
      <td>158</td>
      <td>45</td>
      <td>4</td>
      <td>49</td>
      <td>41</td>
      <td>0.918367</td>
      <td>0.808109</td>
    </tr>
  </tbody>
</table>
</div>




```python
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


# Sentiment Analysis using TextBlob
df[['polarity', 'subjectivity']] = df['reviewText'].apply(lambda text: pd.Series(TextBlob(text).sentiment))

# Sentiment Analysis using VaderSentiment
analyzer = SentimentIntensityAnalyzer()

for index, row in df.iterrows():
    score = analyzer.polarity_scores(row['reviewText'])
    neg = score['neg']
    neu = score['neu']
    pos = score['pos']
    
    if neg > pos:
        df.at[index, 'sentiment'] = "Negative"
    elif pos > neg:
        df.at[index, 'sentiment'] = "Positive"
    else:
        df.at[index, 'sentiment'] = "Neutral"


```


```python
df[df['sentiment'] == 'Positive'].sort_values(by="wilson_lower_bound",
                                                ascending = False).head (5)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>reviewerName</th>
      <th>overall</th>
      <th>reviewText</th>
      <th>reviewTime</th>
      <th>day_diff</th>
      <th>helpful_yes</th>
      <th>helpful_no</th>
      <th>total_vote</th>
      <th>score_pos_neg_diff</th>
      <th>score_average_rating</th>
      <th>wilson_lower_bound</th>
      <th>polarity</th>
      <th>subjectivity</th>
      <th>sentiment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2031</th>
      <td>Hyoun Kim "Faluzure"</td>
      <td>5</td>
      <td>update               so my lovely wife boug...</td>
      <td>05-01-2013</td>
      <td>702</td>
      <td>1952</td>
      <td>68</td>
      <td>2020</td>
      <td>1884</td>
      <td>0.966337</td>
      <td>0.957544</td>
      <td>0.163859</td>
      <td>0.562259</td>
      <td>Positive</td>
    </tr>
    <tr>
      <th>3449</th>
      <td>NLee the Engineer</td>
      <td>5</td>
      <td>i have tested dozens of sdhc and micro sdhc ca...</td>
      <td>26-09-2012</td>
      <td>803</td>
      <td>1428</td>
      <td>77</td>
      <td>1505</td>
      <td>1351</td>
      <td>0.948837</td>
      <td>0.936519</td>
      <td>0.103870</td>
      <td>0.516435</td>
      <td>Positive</td>
    </tr>
    <tr>
      <th>4212</th>
      <td>SkincareCEO</td>
      <td>1</td>
      <td>note   please read the last update  scroll to ...</td>
      <td>08-05-2013</td>
      <td>579</td>
      <td>1568</td>
      <td>126</td>
      <td>1694</td>
      <td>1442</td>
      <td>0.925620</td>
      <td>0.912139</td>
      <td>0.212251</td>
      <td>0.505394</td>
      <td>Positive</td>
    </tr>
    <tr>
      <th>317</th>
      <td>Amazon Customer "Kelly"</td>
      <td>1</td>
      <td>if your card gets hot enough to be painful  it...</td>
      <td>09-02-2012</td>
      <td>1033</td>
      <td>422</td>
      <td>73</td>
      <td>495</td>
      <td>349</td>
      <td>0.852525</td>
      <td>0.818577</td>
      <td>0.143519</td>
      <td>0.494207</td>
      <td>Positive</td>
    </tr>
    <tr>
      <th>4672</th>
      <td>Twister</td>
      <td>5</td>
      <td>sandisk announcement of the first    gb micro ...</td>
      <td>03-07-2014</td>
      <td>158</td>
      <td>45</td>
      <td>4</td>
      <td>49</td>
      <td>41</td>
      <td>0.918367</td>
      <td>0.808109</td>
      <td>0.172332</td>
      <td>0.511282</td>
      <td>Positive</td>
    </tr>
  </tbody>
</table>
</div>




```python
categorical_variable_summary(df,'sentiment')
```


    
![png](output_17_0.png)
    



    
![png](output_17_1.png)
    



```python

```
